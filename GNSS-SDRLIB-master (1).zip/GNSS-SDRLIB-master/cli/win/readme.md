How to compile gnss-sdrcli.exe
-------------------------------------------------------------------------------
* You need Windows 7/8 **64-bit**
* Install Microsoft Visual Studio Express 2012 for Windows Desktop
    * <http://www.microsoft.com/download/details.aspx?id=34673>
* Open *gnss-sdrcli.sln* and change *active solution platform* to **x64**
* Change *active solution configuration* to **release**
* Build gnss-sdrcli and copy gnss-sdrcli.exe to *bin* directory
    * You can use "install.bat" in order to copy gnss-sdrcli.exe
